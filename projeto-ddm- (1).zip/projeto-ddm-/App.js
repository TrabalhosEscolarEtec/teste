import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  Alert,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';

// O componente da tela de cadastro
const TelaDeCadastro = () => {
  // 1. Definição dos Estados usando o Hook useState
  const [nome, setNome] = useState(''); // String
  const [email, setEmail] = useState(''); // String
  const [idade, setIdade] = useState(''); // Int (será validado)
  const [documento, setDocumento] = useState(''); // String

  // 2. Função para manipular o clique no botão Cadastrar
  const handleCadastro = () => {
    // Validação simples (garantindo que a idade é um número)
    const idadeNumerica = parseInt(idade, 10);
    const dadosCompletos = nome && email && idade && documento;

    if (!dadosCompletos) {
      Alert.alert('Erro', 'Por favor, preencha todos os campos.');
      return;
    }

    if (isNaN(idadeNumerica)) {
      Alert.alert('Erro', 'O campo Idade deve ser um número válido.');
      return;
    }
    
    // 3. Estrutura dos Dados a serem cadastrados
    const dadosUsuario = {
      nome: nome,
      email: email,
      idade: idadeNumerica,
      documento: documento,
    };

    // Exibir os dados (simulando o envio para um banco de dados/API)
    Alert.alert(
      'Cadastro Realizado!',
      `Dados:\nNome: ${dadosUsuario.nome}\nE-mail: ${dadosUsuario.email}\nIdade: ${dadosUsuario.idade} anos\nDocumento: ${dadosUsuario.documento}`
    );

    // Limpar o formulário após o cadastro (opcional)
    setNome('');
    setEmail('');
    setIdade('');
    setDocumento('');
  };

  // 4. Estrutura Visual (View, Text, TextInput, Button)
  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 60 : 0}
    >
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Text style={styles.title}>Cadastro de Usuário</Text>

        {/* Campo 1 e 2: Nome (String) */}
        <Text style={styles.label}>1. Nome:</Text>
        <TextInput
          style={styles.input}
          placeholder="Digite seu nome completo"
          value={nome}
          onChangeText={setNome} // Atualiza o estado 'nome'
          keyboardType="default"
        />

        {/* Campo 3 e 4: E-mail (String) */}
        <Text style={styles.label}>3. E-mail:</Text>
        <TextInput
          style={styles.input}
          placeholder="Digite seu e-mail"
          value={email}
          onChangeText={setEmail} // Atualiza o estado 'email'
          keyboardType="email-address"
          autoCapitalize="none"
        />

        {/* Campo 5 e 6: Idade (Int) */}
        <Text style={styles.label}>5. Idade:</Text>
        <TextInput
          style={styles.input}
          placeholder="Digite sua idade"
          value={idade}
          onChangeText={setIdade} // Atualiza o estado 'idade'
          keyboardType="numeric" // Garante que apenas números podem ser digitados
          maxLength={3} // Limita o tamanho
        />

        {/* Campo 7 e 8: Documento (String) */}
        <Text style={styles.label}>7. Documento:</Text>
        <TextInput
          style={styles.input}
          placeholder="Digite seu documento (ex: RG/CPF)"
          value={documento}
          onChangeText={setDocumento} // Atualiza o estado 'documento'
          keyboardType="default"
        />

        {/* Campo 9: Botão Cadastrar */}
        <TouchableOpacity
          style={styles.button}
          onPress={handleCadastro}
        >
          <Text style={styles.buttonText}>Cadastrar</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

// 5. Definição dos Estilos (Styles)
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9e0f3ff', // Cor de fundo suave
    paddingTop: 40, // Espaço no topo para evitar a área da barra de status
  },
  scrollContent: {
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 30,
    textAlign: 'center',
  },
  label: {
    fontSize: 16,
    color: '#555',
    marginTop: 15,
    marginBottom: 5,
    fontWeight: '600',
  },
  input: {
    height: 50,
    borderColor: '#ff87d1ff',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 15,
    fontSize: 16,
    backgroundColor: '#fff',
  },
  button: {
    backgroundColor: '#ffceeaff', // Cor azul vibrante
    padding: 15,
    borderRadius: 8,
    marginTop: 30,
    alignItems: 'center',
    shadowColor: '#000', // Sombra para dar profundidade
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 5,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

// Exporta o componente para ser usado no seu App.js
export default TelaDeCadastro;
